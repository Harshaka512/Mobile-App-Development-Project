package com.example.notetaskapp

data class Todo(
    var item: String?=null
)
